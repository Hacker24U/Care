'use strict';

/*
 * POST /api/login  { username, password }
 *
 * - Verifies credentials against server-side salted scrypt hashes.
 * - Passwords can be reused for unlimited successful logins.
 * - Failed attempts never create a session or mutate account state.
 * - Responds with a bearer session token plus the participant's own reveal
 *   status (and their own partner only if already revealed).
 */

const { json, badRequest, unauthorized, methodNotAllowed, noContent, serverError } = require('./_lib/http');
const store = require('./_lib/store');
const credentials = require('./_lib/credentials');
const { verifyPassword, randomToken, sha256Hex } = require('./_lib/crypto');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Best-effort, per-instance throttle on repeated failures (in-memory only;
// the authoritative protection is that failures never mutate stored state).
const recentFailures = new Map();

function registerFailure(username) {
  if (process.env.SPV_DISABLE_THROTTLE === '1') return false;
  const now = Date.now();
  const list = (recentFailures.get(username) || []).filter((t) => now - t < 60000);
  list.push(now);
  recentFailures.set(username, list);
  return list.length > 5;
}

exports.handler = async (event) => {
  try {
    if (event.httpMethod === 'OPTIONS') return noContent();
    if (event.httpMethod !== 'POST') return methodNotAllowed();

    let body = {};
    try {
      body = JSON.parse(event.body || '{}');
    } catch {
      return badRequest('Invalid request body.');
    }

    const username = typeof body.username === 'string' ? body.username.trim() : '';
    const password = typeof body.password === 'string' ? body.password : '';
    if (!username || !password) return badRequest('Username and password are required.');

    const known = Object.prototype.hasOwnProperty.call(credentials.participants, username);

    if (!known) {
      // Compare against a dummy hash so unknown usernames take a similar
      // amount of time (reduces user-enumeration via timing).
      verifyPassword(password, credentials.dummyHash);
      if (await registerFailure(username)) await sleep(1000);
      return unauthorized('Invalid username or password.');
    }

    // Verify OUTSIDE the lock so failed attempts never touch stored state.
    const existing = await store.getAccountRecord(username);
    const storedHash = (existing && existing.hash) || credentials.participants[username];
    if (!verifyPassword(password, storedHash)) {
      if (await registerFailure(username)) await sleep(1000);
      return unauthorized('Invalid username or password.');
    }

    // Make sure all assignments exist before anyone can reveal anything.
    await store.ensureInitialized();

    const result = await store.withLock(`acct:${username}`, async () => {
      const s = store.getSPVStore();
      let record = await store.getAccountRecord(username);
      if (!record) {
        record = {
          username,
          hash: credentials.participants[username],
          logins: 0,
        };
      }

      const now = new Date().toISOString();
      const token = randomToken(32);
      await s.set(
        store.KEYS.session(sha256Hex(token)),
        JSON.stringify({ username, createdAt: now, lastSeen: now })
      );

      record.logins = (record.logins || 0) + 1;
      // Credentials are reusable. Each successful login gets a fresh session.
      delete record.consumed;
      delete record.consumedAt;
      await s.set(store.KEYS.account(username), JSON.stringify(record));
      return { token };
    });

    const reveal = await store.getReveal(username);
    const payload = {
      ok: true,
      token: result.token,
      username,
      revealed: !!reveal,
    };
    if (reveal) payload.partner = reveal.partner; // only their own partner

    return json(200, payload);
  } catch (err) {
    return serverError(err);
  }
};
