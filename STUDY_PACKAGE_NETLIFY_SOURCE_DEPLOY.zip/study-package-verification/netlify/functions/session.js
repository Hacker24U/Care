'use strict';

/*
 * GET /api/session   (Authorization: Bearer <session token>)
 *
 * Secure session recovery: lets a participant who still holds a valid
 * session resume their existing access after a refresh or browser restart
 * without redeeming their account again. Returns only their own username
 * and their own reveal status/partner (never anyone else's).
 */

const { json, unauthorized, methodNotAllowed, noContent, serverError } = require('./_lib/http');
const store = require('./_lib/store');

exports.handler = async (event) => {
  try {
    if (event.httpMethod === 'OPTIONS') return noContent();
    if (event.httpMethod !== 'GET') return methodNotAllowed();

    const username = await store.authenticate(event);
    if (!username) {
      return unauthorized('Your session is invalid or has expired. Please sign in again.');
    }

    const reveal = await store.getReveal(username);
    const payload = { ok: true, username, revealed: !!reveal };
    if (reveal) payload.partner = reveal.partner; // only their own partner

    return json(200, payload);
  } catch (err) {
    return serverError(err);
  }
};
