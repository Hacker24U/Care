/* GENERATED FILE — SERVER-SIDE ONLY. NEVER PUBLISH OR EDIT BY HAND.
 * Salted scrypt password hashes for the eight authorized participants.
 * Plaintext passwords appear nowhere in this file or in any frontend file.
 * Regenerate with:
 *   printf 'Name|Password\n...' | node scripts/hash-passwords.js
 */
'use strict';

module.exports = {
  // username -> "scrypt$<saltHex>$<hashHex>"
  participants: {
  "Kani": "scrypt$e1882f3d624f77138c8105993b9a14c2$56665eb985e8d2b15ea97a1adf59bdd00520e007d087542e60a1e00650087ec92dd27e2cefe7d4e20d8839c86539cbf6d148c53595e0e2e5ec4fedf2f0527be3",
  "Maya": "scrypt$132571fcfb7f867e5e9fe5e4d892bf20$8bad29e017a8515931b2690ca64579a3ab1c0da5bed6bcb2801083cff84a36214568a4ea3b49d1a18fdad23647d399224613fb5732cd53f2996f783bb3258c99",
  "Vuti": "scrypt$17e6088da942709bbc805c51f020e374$1bc58c87795d19529a5852b35f714c071d6ef8c259c33f3944cab869cb024b20aaeee4eeb943c05df6fdab10cc32a692de3a4cc237d377631c1ee78582d4476b",
  "Oara": "scrypt$7fa01dde2812dd3e726fd479562589bf$49a10834623138169934ee14f8917f4f534e28b63c90c1742a8f6e8ca2da2e23ce703cc0b8afd8e13c9d22ecaff5d57e17731bf1918ebe59d1847b55e566171e",
  "Keems": "scrypt$effd1ffd13ef05d7291cc29a179e352d$bda21c5678d8d4e79f080e2f701923eb3be779bdc6a690ee3a73d68ecde75afd6feec173b43f8a5874342783b7ec6d2cb30f80f907d268c7c0dbd8c2f15a38f8",
  "Wonga": "scrypt$c8408847b0824e002ce8e6304eab6626$91c9d06ffe8cce998b7cf1e39ce79c1e2eba2c1157c2cb9529c973169225ad46336f95e77beb15bf4b5d8cc047a2f6665fe76315edd90b6ad95182037f1440a7",
  "Gere": "scrypt$0c6a11120357c5cd6f56acdfc7e6876e$bad3af2ec0303f5ef6f618a6efb0c48ba1b764b6034eacdffbe5c89807abc634c42547b1ca611e717430ae747f6804297a17947434a6907c6ae1aceec8061d35",
  "Mpumi": "scrypt$5318b92ee5b039bcbaaad33e816134d0$bac273f663f88d6ea6250d3e89af19c4088854363a2d6ff366be05bf15ea6cd9e2535a1f9eba8901ec094a9a1eb6990016bdfc29f3a6d3836e3a7e354b8ae53e"
},

  // Fixed, permanent mutual assignments (these never enter the random pool).
  fixedPairs: {
  "Kani": "Gere",
  "Gere": "Kani",
  "Keems": "Mpumi",
  "Mpumi": "Keems"
},

  // Participants who receive an independent random assignment.
  randomPool: ["Maya","Vuti","Oara","Wonga"],

  // Compared against when the username is unknown, to reduce
  // user-enumeration via response timing.
  dummyHash: "scrypt$a395ecffee915790ec7d09ab3b98e350$25328079cfcfacf4100f27032f9e2c8bb329f73a9625e680135ff986d9b7be0404428b7ffe51d1448a33687a2c32812afc5c705633cb1a65ecea3066501381fd",
};
