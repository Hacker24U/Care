'use strict';

/* Small JSON response helpers for the serverless functions. */

const HEADERS = {
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store',
};

function json(statusCode, obj) {
  return { statusCode, headers: HEADERS, body: JSON.stringify(obj) };
}

function badRequest(message) {
  return json(400, { ok: false, error: message });
}

function unauthorized(message) {
  return json(401, { ok: false, error: message });
}

function methodNotAllowed() {
  return json(405, { ok: false, error: 'Method not allowed.' });
}

function noContent() {
  return { statusCode: 204, headers: { 'Cache-Control': 'no-store' }, body: '' };
}

function serverError(err) {
  // Never leak internals to the client.
  console.error('[spv] internal error:', err);
  return json(500, { ok: false, error: 'Something went wrong. Please try again.' });
}

module.exports = { json, badRequest, unauthorized, methodNotAllowed, noContent, serverError };
