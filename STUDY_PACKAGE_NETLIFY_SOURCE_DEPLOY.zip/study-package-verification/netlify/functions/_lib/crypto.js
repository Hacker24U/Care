'use strict';

/* Cryptographic helpers (Node built-ins only). */

const crypto = require('crypto');

// Stored format: "scrypt$<saltHex>$<hashHex>"
function verifyPassword(password, stored) {
  try {
    const parts = String(stored).split('$');
    if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
    const salt = Buffer.from(parts[1], 'hex');
    const expected = Buffer.from(parts[2], 'hex');
    const computed = crypto.scryptSync(String(password), salt, 64);
    if (computed.length !== expected.length) return false;
    return crypto.timingSafeEqual(computed, expected);
  } catch {
    return false;
  }
}

function sha256Hex(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function randomToken(bytes) {
  return crypto.randomBytes(bytes || 32).toString('hex');
}

// Uniform, cryptographically secure integer in [0, maxExclusive).
function secureRandomInt(maxExclusive) {
  return crypto.randomInt(maxExclusive);
}

module.exports = { verifyPassword, sha256Hex, randomToken, secureRandomInt };
