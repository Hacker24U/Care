'use strict';

/*
 * Netlify Blobs — Netlify's built-in persistent per-site key-value store.
 * It is provisioned automatically for the site on first use: no database,
 * no API keys, no environment variables. Data survives refreshes, browser
 * restarts and redeployments (it is tied to the site, not to any deploy).
 */

const { getStore } = require('@netlify/blobs');

let cached = null;

function getSPVStore() {
  if (!cached) {
    try {
      // Strong consistency: every read observes the latest completed write.
      // Required for the lock + read-modify-write patterns below.
      cached = getStore({ name: 'spv-main', consistency: 'strong' });
    } catch {
      cached = getStore('spv-main');
    }
  }
  return cached;
}

module.exports = { getSPVStore };
