'use strict';

/*
 * Server-side state layer for STUDY PACKAGE VERIFICATION.
 *
 * All persistent state lives in Netlify Blobs (strong consistency):
 *   acct:<username>         -> { username, hash, consumed, consumedAt, logins }
 *   assign:<username>       -> partner name (written exactly once, at init)
 *   reveal:<username>       -> { partner, consumedAt, spinId }
 *   sess:<sha256(token)>    -> { username, createdAt, lastSeen }
 *   lockq:<name>:<id>       -> transient mutex queue entries { id, ts, hb }
 *   meta:initialized        -> '1' once assignments have been generated
 */

const { getSPVStore } = require('./blobs');
const credentials = require('./credentials');
const { sha256Hex, randomToken, secureRandomInt } = require('./crypto');

const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days, sliding

// Mutex tuning. The queue lock is deterministic: at any moment exactly one
// live contender is the unique minimum (ts, id) of the queue and only that
// contender may run its critical section.
const LOCK_TTL_MS = 10000; // an entry with no heartbeat for this long is dead
const LOCK_HEARTBEAT_MS = 1000; // live contenders refresh their entry at least this often
const LOCK_POLL_MS = 25; // base wait between leadership checks

const KEYS = {
  account: (u) => `acct:${u}`,
  assignment: (u) => `assign:${u}`,
  reveal: (u) => `reveal:${u}`,
  session: (tokenHash) => `sess:${tokenHash}`,
  lockQueuePrefix: (name) => `lockq:${name}:`,
  meta: (name) => `meta:${name}`,
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/*
 * Deterministic distributed mutex over the Blobs store (strong consistency).
 *
 * How it works:
 *  - Every contender writes its own queue entry `lockq:<name>:<id>` =
 *    { id, ts (immutable join time), hb (last heartbeat) }.
 *  - The contender whose entry is the unique minimum (ts, id) among LIVE
 *    entries is the leader; only the leader runs the critical section.
 *  - While a leader is inside its critical section its entry is live, so it
 *    remains the unique minimum — no other contender can enter. When it
 *    finishes it deletes its entry and the next minimum takes over.
 *  - Waiting contenders heartbeat their own entries (hb only — ts never
 *    changes, so leadership order is stable). Entries whose heartbeat is
 *    older than LOCK_TTL_MS are treated as dead (crashed holder) and are
 *    lazily removed, so a crash can never deadlock the system.
 *
 * This uses only get/set/delete/list — atomic single-key operations — and
 * guarantees that simultaneous requests cannot both consume an account or
 * both consume a reveal.
 */
async function withLock(name, fn, timeoutMs) {
  const store = getSPVStore();
  const prefix = KEYS.lockQueuePrefix(name);
  const myId = randomToken(8);
  const myTs = Date.now();
  const myKey = `${prefix}${myId}`;
  const deadline = Date.now() + (timeoutMs || 15000);
  let lastHeartbeat = 0;

  const writeEntry = async (hb) => {
    await store.set(myKey, JSON.stringify({ id: myId, ts: myTs, hb }));
    lastHeartbeat = hb;
  };

  await writeEntry(Date.now());

  try {
    for (;;) {
      const now = Date.now();

      const all = await store.list();
      const entries = [];
      for (const blob of (all && all.blobs) || []) {
        if (!blob.key || blob.key.indexOf(prefix) !== 0) continue;
        const raw = await store.get(blob.key);
        if (!raw) continue;
        try {
          const e = JSON.parse(raw);
          if (e && e.id && typeof e.ts === 'number') entries.push(e);
        } catch {
          // Malformed entry — ignore.
        }
      }

      // Split live vs. dead (heartbeat expired) and lazily remove the dead.
      const live = [];
      for (const e of entries) {
        if (now - (e.hb || e.ts) < LOCK_TTL_MS) live.push(e);
        else await store.delete(`${prefix}${e.id}`).catch(() => {});
      }

      if (live.length) {
        live.sort((a, b) => (a.ts - b.ts) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
        const leader = live[0];
        if (leader.id === myId) {
          // I am the unique minimum — I hold the lock. Heartbeat, then run.
          await writeEntry(Date.now());
          return await fn();
        }
      } else {
        // No live entries (cannot normally happen while I am alive) — re-assert.
        await writeEntry(Date.now());
      }

      if (Date.now() > deadline) {
        throw new Error('Could not acquire the state lock. Please try again.');
      }
      if (Date.now() - lastHeartbeat > LOCK_HEARTBEAT_MS) await writeEntry(Date.now());
      await sleep(LOCK_POLL_MS + Math.random() * 25);
    }
  } finally {
    await store.delete(myKey).catch(() => {});
  }
}

let initPromise = null;

/*
 * Generates ALL partner assignments exactly once, before the first reveal:
 *  - fixed mutual pairs (never in the random pool)
 *  - independent random assignments for the pool members, using
 *    crypto.randomInt (secure randomization) — a participant never receives
 *    themselves; assignments need not be reciprocal.
 * The result is saved permanently and never rerandomized.
 */
async function ensureInitialized() {
  const store = getSPVStore();
  const flag = await store.get(KEYS.meta('initialized'));
  if (flag === '1') return;

  if (!initPromise) {
    initPromise = withLock('init', async () => {
      const again = await store.get(KEYS.meta('initialized'));
      if (again === '1') return;

      for (const [a, b] of Object.entries(credentials.fixedPairs)) {
        await store.set(KEYS.assignment(a), b);
      }

      const pool = credentials.randomPool.slice();
      for (const member of pool) {
        const others = pool.filter((p) => p !== member);
        const partner = others[secureRandomInt(others.length)];
        await store.set(KEYS.assignment(member), partner);
      }

      await store.set(KEYS.meta('initialized'), '1');
    }).finally(() => {
      initPromise = null;
    });
  }
  await initPromise;
}

async function getAssignment(username) {
  await ensureInitialized();
  return getSPVStore().get(KEYS.assignment(username));
}

async function getReveal(username) {
  const raw = await getSPVStore().get(KEYS.reveal(username));
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function getAccountRecord(username) {
  const raw = await getSPVStore().get(KEYS.account(username));
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/*
 * Validates the bearer session token from the Authorization header (or a
 * ?token= query parameter). Returns the username, or null. Sliding 30-day
 * expiry; the token itself is stored only as a SHA-256 hash.
 */
async function authenticate(event) {
  const headers = (event && event.headers) || {};
  const auth = headers['authorization'] || headers['Authorization'] || '';
  const match = /^Bearer\s+(\S+)$/i.exec(String(auth));
  const token = match
    ? match[1]
    : (((event && event.queryStringParameters) || {}).token || '');
  if (!token) return null;

  const store = getSPVStore();
  const key = KEYS.session(sha256Hex(token));
  const raw = await store.get(key);
  if (!raw) return null;

  try {
    const record = JSON.parse(raw);
    const lastSeen = new Date(record.lastSeen || record.createdAt).getTime();
    if (Date.now() - lastSeen > SESSION_TTL_MS) {
      await store.delete(key).catch(() => {});
      return null;
    }
    record.lastSeen = new Date().toISOString();
    await store.set(key, JSON.stringify(record));
    return record.username;
  } catch {
    return null;
  }
}

module.exports = {
  KEYS,
  SESSION_TTL_MS,
  withLock,
  ensureInitialized,
  getAssignment,
  getReveal,
  getAccountRecord,
  authenticate,
  getSPVStore,
};
