'use strict';

/*
 * POST /api/spin   (Authorization: Bearer <session token>)
 *
 * One-time partner reveal:
 *   1. Validates the authenticated participant.
 *   2. Verifies the reveal has not already been consumed.
 *   3. Atomically marks the reveal as consumed (store lock).
 *   4. Retrieves ONLY the participant's saved partner.
 * The response never contains any other participant's assignment.
 *
 * If the reveal was already consumed (e.g. the connection dropped after the
 * reveal was recorded), the same saved partner is returned again — a secure
 * recovery flow that never creates a new reveal.
 */

const { json, unauthorized, methodNotAllowed, noContent, serverError } = require('./_lib/http');
const store = require('./_lib/store');
const { randomToken } = require('./_lib/crypto');

exports.handler = async (event) => {
  try {
    if (event.httpMethod === 'OPTIONS') return noContent();
    if (event.httpMethod !== 'POST') return methodNotAllowed();

    const username = await store.authenticate(event);
    if (!username) {
      return unauthorized('Your session is invalid or has expired. Please sign in again.');
    }

    await store.ensureInitialized();

    const result = await store.withLock(`reveal:${username}`, async () => {
      const s = store.getSPVStore();
      const revealKey = store.KEYS.reveal(username);

      const existing = await store.getReveal(username);
      if (existing && existing.partner) {
        // Recovery: the reveal was already consumed — return the same result.
        return { alreadyRevealed: true, partner: existing.partner };
      }

      const partner = await s.get(store.KEYS.assignment(username));
      if (!partner) throw new Error('No partner assignment found for this account.');

      const record = {
        partner,
        consumedAt: new Date().toISOString(),
        spinId: randomToken(8),
      };
      await s.set(revealKey, JSON.stringify(record));
      return { alreadyRevealed: false, partner };
    });

    return json(200, {
      ok: true,
      username,
      alreadyRevealed: result.alreadyRevealed,
      partner: result.partner,
    });
  } catch (err) {
    return serverError(err);
  }
};
