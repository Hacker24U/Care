# STUDY PACKAGE VERIFICATION
### Secure Participant Verification Portal — Netlify "upload-and-go" edition

A complete, self-contained website for **eight authorized participants**.
Log in once, spin the wheel once, reveal your study partner once. Every
one-time rule is enforced **server-side** and survives refreshes, browser
restarts, and website redeployments.

**Zero manual setup:** no database to create, no SQL, no API keys, no
environment variables, no build step, nothing to install on your computer.
You upload one folder to Netlify and it works.

---

## What's in the ZIP

| Path | Purpose |
|---|---|
| `site/` | The complete production frontend (HTML / CSS / JS). This is the published website — plain static files, **no build step**, zero browser dependencies. |
| `netlify/functions/` | Serverless API (`login`, `spin`, `session`) + shared server-side library (`_lib/`). |
| `netlify.toml` | Netlify configuration: publish dir, functions dir, `/api/*` routes, security headers. |
| `package.json` | Declares the single function dependency (`@netlify/blobs`) — installed automatically by Netlify at deploy time. |
| `scripts/hash-passwords.js` | Utility that generated the password hashes (plaintext is never stored). |
| `tests/` | Automated test suite + local dev server (uses a file-backed test shim for Netlify Blobs). |
| `README.md` | This file. |

---

## Deploy correctly (important: use a Git-connected deploy)

**Do not use Netlify Drop / drag-and-drop for this project.** That workflow can publish the static `site/` files without building the serverless functions. The login page will load, but `/api/login` can fail and show “Something went wrong.”

This project needs Netlify to build and deploy `netlify/functions/` and install `@netlify/blobs`. Use a Git-connected Netlify deployment:

1. Extract this ZIP on your phone or computer.
2. Put the *contents* of the `study-package-verification` folder at the root of a GitHub repository (the root must contain `netlify.toml`, `package.json`, `site/`, and `netlify/functions/`).
3. In Netlify, choose **Add new site → Import an existing project** and connect that GitHub repository.
4. Keep the build settings from `netlify.toml`: publish directory `site`, functions directory `netlify/functions`, and no custom build command required.
5. Deploy, then open the Netlify Functions page and confirm `login`, `session`, and `spin` were deployed.
6. Try login again. If it still fails, open the `login` function logs; the `[spv] internal error` entry will show the underlying production issue.

**Why a ZIP alone cannot fix a drag-and-drop deploy:** Netlify Drop is for static deploys; it does not run the source build needed to bundle these serverless functions. This ZIP is the source package for a Git-connected deployment, not a static upload artifact.

## Other deployment options

- Netlify CLI: run `npm install`, `netlify login`, `netlify link`, and `netlify deploy --prod` from this project root.
- Git: push the project root to GitHub/GitLab/Bitbucket and import that repository into Netlify.

---

## Authorized credentials

Usernames and passwords are matched **exactly** (case-sensitive; surrounding
whitespace is trimmed). Passwords are stored only as salted **scrypt** hashes
inside the serverless backend — plaintext passwords appear nowhere in the
frontend or in any published file.

| Username | Password |
|---|---|
| Kani | Kani18 |
| Maya | Maya17 |
| Vuti | Vuti17 |
| Oara | Oara17 |
| Keems | Keems18 |
| Wonga | Wonga18 |
| Gere | Gere18 |
| Mpumi | Mpumi18 |

---

## How the rules are enforced

### One-time login (server-side)
- The **first successful login** atomically marks the account as consumed in
  Netlify Blobs. A deterministic queue-based mutex guarantees that even
  simultaneous requests consume the account **exactly once**.
- **Failed logins never consume the account** (password verification happens
  outside the lock and touches no stored state).
- **Session recovery:** a consumed account can authenticate again with the
  same password to receive a *new session* — this is a recovery, **not** a
  re-redemption. The consumption record is immutable and never changes.
- Consumption survives refreshes, browser restarts and redeployments because
  it lives in the site's persistent store, not in the browser.

### Permanent partner assignments
- **Fixed pairs (never in the random pool):** Kani ↔ Gere, Keems ↔ Mpumi.
- **Independent random assignments** for Maya, Vuti, Oara, Wonga: each
  receives one randomly selected partner from the other three pool members,
  using `crypto.randomInt` (secure randomization). A participant never
  receives themselves; assignments need not be reciprocal (e.g. Wonga may
  receive Vuti while Vuti receives Maya).
- **All assignments are generated before the first reveal**, saved
  permanently, and **never rerandomized** on login, refresh or redeploy.

### One-time spin
- Clicking **CLICK FOR PAIR** calls the backend, which (1) validates the
  session, (2) checks the reveal is unconsumed, (3) **atomically** marks it
  consumed, and (4) returns **only the participant's own** saved partner.
- The wheel animation is purely decorative — it lands on the segment of the
  partner the backend already saved. It can never generate or change a result.
- Spinning again shows **"YOUR PARTNER HAS ALREADY BEEN REVEALED"** (with the
  same saved partner, for recovery).
- If the connection drops *after* the reveal was recorded, retrying is safe:
  the backend returns the same saved result without creating a new reveal.

### Seven-name spinning wheel
- Full-screen canvas wheel with the **other seven** participants' names (the
  logged-in participant's own name is excluded), smooth rotation, gradual
  deceleration (ease-out cubic), rotating spotlight, gold ring/pointer/hub,
  vignette, tick sounds and a landing chime (WebAudio — no audio files), and
  a **mute button**.
- The wheel shows names only. It never shows who anyone is assigned to.

### Privacy
- The backend returns **only the authorized participant's own partner** —
  never the assignment table, never another participant's result.
- Participants cannot retrieve anyone else's partner by editing a URL,
  changing an ID, modifying a request, or inspecting the frontend: the
  frontend contains no assignments and no secrets, and every request is
  authenticated against a server-side session.
- Security headers (CSP, X-Frame-Options, nosniff, …) are set in `netlify.toml`.

---

## Security notes

- Passwords: salted **scrypt** hashes (per-user random salt), verified with
  `crypto.timingSafeEqual`. A dummy hash is compared for unknown usernames to
  reduce user-enumeration via timing. A best-effort per-instance throttle
  delays responses after repeated failures.
- Sessions: 256-bit random bearer tokens, stored **only as SHA-256 hashes**
  server-side, with a sliding 30-day expiry. The browser keeps the token in
  `localStorage` so a refresh or browser restart resumes the same access.
- State: Netlify Blobs with **strong consistency** — reads always observe
  the latest completed write, which the mutex relies on.
- Mutual exclusion: a deterministic queue-based mutex (unique minimum
  `(timestamp, id)` among heartbeated queue entries) built only from atomic
  single-key get/set/delete/list operations. A crashed holder can never
  deadlock the system (heartbeat TTL + lazy cleanup).

## Honest limitations

1. **Deploy the whole folder** (see the warning above). Dragging only `site/`
   produces a frontend with no backend — the one-time rules would not be
   enforceable.
2. **Netlify Blobs usage limits** apply on the free tier (requests and
   storage). For eight participants the usage is a tiny fraction of the
   allowance.
3. **Deleting the Netlify site** deletes its Blobs data. Redeploying the
   site does **not** — all state is preserved.
4. Sessions are bearer tokens kept in the participant's own browser. That is
   fine for this use case; the one-time rules themselves are enforced
   server-side and cannot be bypassed by clearing browser storage.
5. The mutex is deterministic given strong-consistency reads (which Netlify
   Blobs provides when requested). It is designed and tested for this scale
   (eight participants); it is not a substitute for a transactional database
   under heavy adversarial concurrency.

---

## Testing

The project ships with an automated suite that runs the **real** function
handlers against a file-backed Netlify Blobs test shim (including
persistence across separate processes, which simulates restarts and
redeployments):

```bash
node tests/run-tests.js
```

It covers: all eight credentials · one-time account consumption (including
20 simultaneous logins) · failed attempts never consuming · the four fixed
assignments · independent random assignments for the pool (validity and
permanence) · one-time spinning (including 20 simultaneous spins) · session
recovery · persistence across processes · the seven-name wheel lists · no
secrets in frontend files · Netlify configuration completeness.

Local preview of the full stack (frontend + API):

```bash
node tests/local-server.js    # then open http://localhost:8888
```

Mobile responsiveness is handled with a viewport meta tag, fluid card widths
(`min(…, 94vw)`), a `max-width: 480px` media query, and a DPR-aware canvas
that resizes with the window — worth a quick manual check on a phone.

---

## Project structure

```
study-package-verification/
├── netlify.toml                  # Netlify config (publish, functions, routes, headers)
├── package.json                  # single dependency: @netlify/blobs
├── README.md
├── site/                         # the published production frontend (no build step)
│   ├── index.html                # login / main / wheel / reveal screens
│   ├── css/style.css             # dark navy & black, white text, gold accents
│   └── js/
│       ├── logic.js              # participant list + wheel-name logic
│       └── app.js                # app controller, canvas wheel, WebAudio SFX
├── netlify/functions/            # serverless API (deployed automatically)
│   ├── login.js                  # POST /api/login
│   ├── spin.js                   # POST /api/spin
│   ├── session.js                # GET  /api/session
│   └── _lib/
│       ├── blobs.js              # Netlify Blobs store (strong consistency)
│       ├── credentials.js        # GENERATED: scrypt hashes (server-side only)
│       ├── crypto.js             # scrypt verify, tokens, secure random
│       ├── http.js               # JSON response helpers
│       └── store.js              # state layer + queue mutex + assignments
├── scripts/
│   └── hash-passwords.js         # regenerates credentials.js from stdin
└── tests/
    ├── run-tests.js              # automated test suite
    ├── local-server.js           # local full-stack dev server
    ├── child-probe.js            # cross-process persistence probe
    └── shims/@netlify/blobs/     # file-backed test shim (not the real package)
```

---

## Regenerating credentials

If you ever change a participant's password, regenerate the server-side hash
file (plaintext is read from stdin and never written to disk):

```bash
printf 'Kani|NewPassword18\nMaya|Maya17\n...' | node scripts/hash-passwords.js \
  > netlify/functions/_lib/credentials.js
```

Then redeploy. Existing consumption/reveal state is preserved.
