/* ==========================================================================
   STUDY PACKAGE VERIFICATION — shared, dependency-free frontend logic.
   Exposes window.SPV (or globalThis.SPV when loaded outside a browser,
   e.g. by the Node test suite).
   ========================================================================== */
(function (global) {
  'use strict';

  // Canonical participant order. The spinning wheel always shows the other
  // seven participants in this order (the participant's own name excluded).
  var PARTICIPANTS = ['Kani', 'Maya', 'Vuti', 'Oara', 'Keems', 'Wonga', 'Gere', 'Mpumi'];

  // The seven names shown on the wheel for a given participant:
  // everyone except the participant themselves, in canonical order.
  function wheelNamesFor(username) {
    return PARTICIPANTS.filter(function (name) { return name !== username; });
  }

  global.SPV = {
    PARTICIPANTS: PARTICIPANTS,
    wheelNamesFor: wheelNamesFor
  };
})(typeof window !== 'undefined' ? window : globalThis);
