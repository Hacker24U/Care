/* ==========================================================================
   STUDY PACKAGE VERIFICATION — frontend application controller.
   Talks only to the same-origin serverless API (/api/*). The backend is the
   single source of truth for authentication, one-time consumption, partner
   assignments and reveals; this file never contains assignments or secrets.
   ========================================================================== */
(function () {
  'use strict';

  var TOKEN_KEY = 'spv_session_token';

  var screens = {
    login: document.getElementById('screen-login'),
    main: document.getElementById('screen-main'),
    wheel: document.getElementById('screen-wheel'),
    reveal: document.getElementById('screen-reveal')
  };

  var loginForm = document.getElementById('login-form');
  var usernameInput = document.getElementById('login-username');
  var passwordInput = document.getElementById('login-password');
  var loginError = document.getElementById('login-error');
  var loginSubmit = document.getElementById('login-submit');

  var welcomeName = document.getElementById('welcome-name');
  var pairButton = document.getElementById('pair-button');
  var mainError = document.getElementById('main-error');
  var signoutButton = document.getElementById('signout-button');

  var muteButton = document.getElementById('mute-button');
  var revealHeading = document.getElementById('reveal-heading');
  var revealPartner = document.getElementById('reveal-partner');
  var revealDone = document.getElementById('reveal-done');

  var state = { token: null, username: null, revealed: false, partner: null };
  var spinInProgress = false;

  /* ---------------- helpers ---------------- */

  function showScreen(name) {
    Object.keys(screens).forEach(function (key) {
      screens[key].classList.toggle('active', key === name);
    });
    if (name === 'wheel') wheel.resize();
  }

  function showError(el, message) { el.textContent = message; el.hidden = false; }
  function clearError(el) { el.textContent = ''; el.hidden = true; }

  function api(path, options) {
    var opts = { method: (options && options.method) || 'GET', headers: {} };
    if (options && options.body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(options.body);
    }
    if (state.token) opts.headers['Authorization'] = 'Bearer ' + state.token;
    return fetch(path, opts).then(function (res) {
      return res.json().catch(function () { return null; }).then(function (data) {
        if (!res.ok) {
          var err = new Error((data && data.error) || 'Request failed (' + res.status + ').');
          err.status = res.status;
          throw err;
        }
        return data;
      });
    });
  }

  /* ---------------- sound effects (WebAudio, no assets) ---------------- */

  var AudioFX = {
    ctx: null,
    muted: false,
    ensure: function () {
      if (!this.ctx) {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (AC) this.ctx = new AC();
      }
      if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
    },
    blip: function (freq, dur, type, vol) {
      if (this.muted || !this.ctx) return;
      var t = this.ctx.currentTime;
      var osc = this.ctx.createOscillator();
      var gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(vol, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(t);
      osc.stop(t + dur);
    },
    tick: function () { this.ensure(); this.blip(1800 + Math.random() * 600, 0.05, 'square', 0.045); },
    ding: function () {
      this.ensure();
      this.blip(880, 0.5, 'sine', 0.12);
      this.blip(1318.51, 0.65, 'sine', 0.07);
    }
  };

  /* ---------------- seven-name spinning wheel (canvas) ---------------- */

  var wheel = {
    canvas: document.getElementById('wheel-canvas'),
    names: [],
    rotation: 0,
    dpr: 1, W: 0, H: 0, cx: 0, cy: 0, radius: 0,

    resize: function () {
      var c = this.canvas;
      this.dpr = window.devicePixelRatio || 1;
      this.W = window.innerWidth;
      this.H = window.innerHeight;
      c.width = Math.round(this.W * this.dpr);
      c.height = Math.round(this.H * this.dpr);
      c.style.width = this.W + 'px';
      c.style.height = this.H + 'px';
      this.cx = this.W / 2;
      this.cy = this.H / 2 + this.H * 0.02;
      this.radius = Math.min(this.W, this.H) * (this.W < 640 ? 0.42 : 0.36);
      this.draw(this.rotation);
    },

    setNames: function (names) {
      this.names = names.slice();
      this.rotation = 0;
      this.draw(0);
    },

    draw: function (rot) {
      this.rotation = rot;
      var g = this.ctx;
      var W = this.W, H = this.H, cx = this.cx, cy = this.cy, r = this.radius;
      var names = this.names;
      if (!g || !W || !r || !names.length) return;

      g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);

      // dramatic background lighting
      var bg = g.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * 0.8);
      bg.addColorStop(0, '#14224a');
      bg.addColorStop(0.5, '#0a1530');
      bg.addColorStop(1, '#02040a');
      g.fillStyle = bg;
      g.fillRect(0, 0, W, H);

      var twoPi = Math.PI * 2;
      var seg = twoPi / names.length;

      g.save();
      g.translate(cx, cy);

      // slowly rotating spotlight sweep
      g.save();
      g.rotate(rot * 0.6 + performance.now() / 4000);
      g.beginPath();
      g.moveTo(0, 0);
      g.arc(0, 0, r, -0.35, 0.35);
      g.closePath();
      var sweep = g.createLinearGradient(-r, 0, r, 0);
      sweep.addColorStop(0, 'rgba(255,255,255,0)');
      sweep.addColorStop(0.5, 'rgba(255,240,200,0.10)');
      sweep.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = sweep;
      g.fill();
      g.restore();

      // outer gold ring with glow
      g.beginPath();
      g.arc(0, 0, r, 0, twoPi);
      g.fillStyle = '#0b1730';
      g.fill();
      g.lineWidth = Math.max(3, r * 0.012);
      g.strokeStyle = '#d4af37';
      g.shadowColor = 'rgba(240, 199, 94, 0.55)';
      g.shadowBlur = r * 0.08;
      g.stroke();
      g.shadowBlur = 0;

      // segments
      var i, a0, a1;
      for (i = 0; i < names.length; i++) {
        a0 = i * seg + rot;
        a1 = (i + 1) * seg + rot;
        g.beginPath();
        g.moveTo(0, 0);
        g.arc(0, 0, r * 0.985, a0, a1);
        g.closePath();
        g.fillStyle = i % 2 === 0 ? '#152a5c' : '#0d1c40';
        g.fill();
        g.strokeStyle = 'rgba(212, 175, 55, 0.9)';
        g.lineWidth = Math.max(1.5, r * 0.006);
        g.stroke();
      }

      // names (white, radial)
      var fontSize = Math.max(13, Math.min(26, r * 0.085));
      g.font = '600 ' + fontSize + 'px "Segoe UI", system-ui, sans-serif';
      g.textAlign = 'right';
      g.textBaseline = 'middle';
      for (i = 0; i < names.length; i++) {
        var mid = i * seg + seg / 2 + rot;
        g.save();
        g.rotate(mid);
        g.fillStyle = '#ffffff';
        g.shadowColor = 'rgba(0,0,0,0.8)';
        g.shadowBlur = 4;
        g.fillText(names[i].toUpperCase(), r * 0.93, 0);
        g.restore();
      }
      g.shadowBlur = 0;

      // gold center hub
      var hub = r * 0.16;
      var hg = g.createRadialGradient(0, 0, 0, 0, 0, hub);
      hg.addColorStop(0, '#f7dc8a');
      hg.addColorStop(0.6, '#d4af37');
      hg.addColorStop(1, '#8a6a1f');
      g.beginPath();
      g.arc(0, 0, hub, 0, twoPi);
      g.fillStyle = hg;
      g.fill();
      g.lineWidth = Math.max(2, r * 0.006);
      g.strokeStyle = '#0a1428';
      g.stroke();
      g.beginPath();
      g.arc(0, 0, hub * 0.62, 0, twoPi);
      g.fillStyle = '#0a1428';
      g.fill();
      g.font = '700 ' + Math.max(14, hub * 0.55) + 'px "Segoe UI", system-ui, sans-serif';
      g.textAlign = 'center';
      g.textBaseline = 'middle';
      g.fillStyle = '#f0c75e';
      g.fillText('\u2605', 0, hub * 0.03);

      g.restore();

      // gold pointer at the top
      var px = cx;
      var py = cy - r;
      var pw = r * 0.045;
      var ph = r * 0.09;
      g.save();
      g.shadowColor = 'rgba(240, 199, 94, 0.9)';
      g.shadowBlur = 18;
      g.beginPath();
      g.moveTo(px - pw, py - ph);
      g.lineTo(px + pw, py - ph);
      g.lineTo(px, py + 4);
      g.closePath();
      var pg = g.createLinearGradient(0, py - ph, 0, py + 4);
      pg.addColorStop(0, '#f7dc8a');
      pg.addColorStop(1, '#b8892b');
      g.fillStyle = pg;
      g.fill();
      g.restore();

      // vignette
      var vg = g.createRadialGradient(cx, cy, r * 0.9, cx, cy, Math.max(W, H) * 0.75);
      vg.addColorStop(0, 'rgba(0,0,0,0)');
      vg.addColorStop(1, 'rgba(0,0,0,0.55)');
      g.fillStyle = vg;
      g.fillRect(0, 0, W, H);
    },

    // Decorative spin. The final resting segment is chosen to match the
    // partner returned by the backend — the animation never decides the
    // result, it only presents it.
    spinTo: function (targetIndex, onDone) {
      var self = this;
      var names = this.names;
      var twoPi = Math.PI * 2;
      var seg = twoPi / names.length;
      var reduceMotion = window.matchMedia &&
        window.matchMedia('(prefers-reduced-motion: reduce)').matches;

      var offset = seg * (0.18 + Math.random() * 0.64); // land inside the segment
      var targetWheelAngle = targetIndex * seg + offset;
      var pointerAngle = -Math.PI / 2; // pointer sits at the top

      var final = pointerAngle - targetWheelAngle;
      final = Math.ceil((final - this.rotation) / twoPi) * twoPi + final;
      final += (5 + Math.floor(Math.random() * 3)) * twoPi; // several full turns

      var start = this.rotation;
      var delta = final - start;
      var duration = reduceMotion ? 1200 : 5200 + Math.random() * 900;
      var t0 = performance.now();
      var lastIndex = -1;

      function frame(now) {
        var t = Math.min(1, (now - t0) / duration);
        var eased = 1 - Math.pow(1 - t, 3); // ease-out cubic: fast start, gradual deceleration
        var rot = start + delta * eased;
        self.draw(rot);

        // tick sound on every segment crossing
        var pointerWheel = (((pointerAngle - rot) % twoPi) + twoPi) % twoPi;
        var idx = Math.floor(pointerWheel / seg);
        if (idx !== lastIndex) {
          lastIndex = idx;
          if (t > 0.02 && t < 0.995) AudioFX.tick();
        }

        if (t < 1) {
          requestAnimationFrame(frame);
        } else {
          self.draw(final);
          AudioFX.ding();
          if (onDone) onDone();
        }
      }
      requestAnimationFrame(frame);
    }
  };
  wheel.ctx = wheel.canvas.getContext('2d');

  window.addEventListener('resize', function () {
    if (screens.wheel.classList.contains('active')) wheel.resize();
  });

  /* ---------------- screens ---------------- */

  function showMain() {
    welcomeName.textContent = state.username || '';
    clearError(mainError);
    showScreen('main');
  }

  function showReveal(already) {
    revealHeading.textContent = already
      ? 'YOUR PARTNER HAS ALREADY BEEN REVEALED'
      : 'YOUR STUDY PARTNER IS';
    revealPartner.textContent = state.partner || '\u2014';
    showScreen('reveal');
  }

  /* ---------------- actions ---------------- */

  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    clearError(loginError);
    loginSubmit.disabled = true;
    loginSubmit.textContent = 'VERIFYING\u2026';
    api('/api/login', {
      method: 'POST',
      body: { username: usernameInput.value, password: passwordInput.value }
    })
      .then(function (res) {
        state.token = res.token;
        state.username = res.username;
        state.revealed = !!res.revealed;
        state.partner = res.partner || null;
        try { localStorage.setItem(TOKEN_KEY, res.token); } catch (err) { /* private mode */ }
        passwordInput.value = '';
        if (state.revealed) showReveal(true);
        else showMain();
      })
      .catch(function (err) {
        showError(loginError, err.message || 'Access denied.');
      })
      .finally(function () {
        loginSubmit.disabled = false;
        loginSubmit.textContent = 'VERIFY ACCESS';
      });
  });

  pairButton.addEventListener('click', function () {
    if (spinInProgress) return;
    spinInProgress = true;
    clearError(mainError);
    pairButton.disabled = true;
    api('/api/spin', { method: 'POST' })
      .then(function (res) {
        // The backend has atomically consumed the reveal and returned ONLY
        // this participant's saved partner.
        state.revealed = true;
        state.partner = res.partner;
        if (res.alreadyRevealed) {
          showReveal(true);
        } else {
          var names = window.SPV.wheelNamesFor(state.username);
          var target = Math.max(0, names.indexOf(res.partner));
          wheel.setNames(names);
          showScreen('wheel');
          wheel.spinTo(target, function () { showReveal(false); });
        }
      })
      .catch(function (err) {
        // Safe to retry: if the reveal was already recorded, the backend
        // returns the same saved result (recovery flow).
        showError(mainError, err.message || 'Connection failed. Please check your connection and try again.');
      })
      .finally(function () {
        spinInProgress = false;
        pairButton.disabled = false;
      });
  });

  revealDone.addEventListener('click', function () { showMain(); });

  signoutButton.addEventListener('click', function () {
    state.token = null;
    state.username = null;
    state.revealed = false;
    state.partner = null;
    try { localStorage.removeItem(TOKEN_KEY); } catch (err) { /* ignore */ }
    showScreen('login');
  });

  muteButton.addEventListener('click', function () {
    AudioFX.muted = !AudioFX.muted;
    muteButton.innerHTML = AudioFX.muted ? '&#128263;' : '&#128266;';
    muteButton.setAttribute('aria-pressed', String(AudioFX.muted));
  });

  /* ---------------- boot / secure session recovery ---------------- */

  function boot() {
    var saved = null;
    try { saved = localStorage.getItem(TOKEN_KEY); } catch (err) { /* ignore */ }
    if (saved) {
      state.token = saved;
      api('/api/session', { method: 'GET' })
        .then(function (res) {
          state.username = res.username;
          state.revealed = !!res.revealed;
          state.partner = res.partner || null;
          if (state.revealed) { showReveal(true); return; }
          showMain();
        })
        .catch(function () {
          state.token = null;
          try { localStorage.removeItem(TOKEN_KEY); } catch (err) { /* ignore */ }
          showScreen('login');
        });
    } else {
      showScreen('login');
    }
  }

  boot();
})();
