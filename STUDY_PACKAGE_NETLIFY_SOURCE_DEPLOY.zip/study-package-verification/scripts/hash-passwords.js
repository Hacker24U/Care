#!/usr/bin/env node
'use strict';

/*
 * Generates netlify/functions/_lib/credentials.js containing salted scrypt
 * password hashes. Plaintext passwords are read from STDIN and are never
 * written to disk.
 *
 * Usage (from the project root):
 *   printf 'Name1|Password1\nName2|Password2\n...' | node scripts/hash-passwords.js \
 *     > netlify/functions/_lib/credentials.js
 */

const readline = require('readline');
const crypto = require('crypto');

const FIXED_PAIRS = { Kani: 'Gere', Gere: 'Kani', Keems: 'Mpumi', Mpumi: 'Keems' };
const RANDOM_POOL = ['Maya', 'Vuti', 'Oara', 'Wonga'];

function scryptEntry(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), Buffer.from(salt, 'hex'), 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

const participants = {};
const rl = readline.createInterface({ input: process.stdin, terminal: false });

rl.on('line', (line) => {
  const idx = line.indexOf('|');
  if (idx === -1) return;
  const username = line.slice(0, idx).trim();
  const password = line.slice(idx + 1);
  if (!username || !password) return;
  participants[username] = scryptEntry(password);
});

rl.on('close', () => {
  const dummyHash = scryptEntry('dummy-not-a-real-password-' + crypto.randomBytes(8).toString('hex'));
  const out = `/* GENERATED FILE — SERVER-SIDE ONLY. NEVER PUBLISH OR EDIT BY HAND.
 * Salted scrypt password hashes for the eight authorized participants.
 * Plaintext passwords appear nowhere in this file or in any frontend file.
 * Regenerate with:
 *   printf 'Name|Password\\n...' | node scripts/hash-passwords.js
 */
'use strict';

module.exports = {
  // username -> "scrypt$<saltHex>$<hashHex>"
  participants: ${JSON.stringify(participants, null, 2)},

  // Fixed, permanent mutual assignments (these never enter the random pool).
  fixedPairs: ${JSON.stringify(FIXED_PAIRS, null, 2)},

  // Participants who receive an independent random assignment.
  randomPool: ${JSON.stringify(RANDOM_POOL)},

  // Compared against when the username is unknown, to reduce
  // user-enumeration via response timing.
  dummyHash: ${JSON.stringify(dummyHash)},
};
`;
  process.stdout.write(out);
});
