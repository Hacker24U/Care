'use strict';

/*
 * Local development server: serves site/ and wires /api/* to the REAL
 * Netlify function handlers (backed by the file-based Blobs test shim).
 *
 * Run from the project root:  node tests/local-server.js
 * Then open:                  http://localhost:8888
 */

const Module = require('module');
const path = require('path');
const fs = require('fs');
const http = require('http');

const SHIM = path.join(__dirname, 'shims', '@netlify', 'blobs', 'index.js');
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function (request, ...rest) {
  if (request === '@netlify/blobs') return SHIM;
  return originalResolve.call(this, request, ...rest);
};

process.env.BLOBS_MOCK_FILE = process.env.BLOBS_MOCK_FILE || path.join(__dirname, '.mock-blobs.json');
process.env.SPV_DISABLE_THROTTLE = '1';

const siteDir = path.join(__dirname, '..', 'site');
const functions = {
  login: require('../netlify/functions/login.js'),
  spin: require('../netlify/functions/spin.js'),
  session: require('../netlify/functions/session.js'),
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');

  if (url.pathname.startsWith('/api/')) {
    const fn = functions[url.pathname.slice('/api/'.length)];
    if (!fn) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end('{"error":"not found"}');
      return;
    }
    let body = '';
    req.on('data', (chunk) => { body += chunk; });
    req.on('end', async () => {
      try {
        const event = {
          httpMethod: req.method,
          headers: req.headers,
          body: body || undefined,
          path: url.pathname,
          queryStringParameters: Object.fromEntries(url.searchParams.entries()),
        };
        const out = await fn.handler(event);
        res.writeHead(out.statusCode || 200, out.headers || { 'Content-Type': 'application/json' });
        res.end(out.body || '');
      } catch (err) {
        console.error(err);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end('{"error":"internal error"}');
      }
    });
    return;
  }

  let rel = decodeURIComponent(url.pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(siteDir, rel));
  if (!file.startsWith(siteDir) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found');
    return;
  }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});

const port = Number(process.env.PORT || 8888);
server.listen(port, '0.0.0.0', () => {
  console.log(`STUDY PACKAGE VERIFICATION local server -> http://localhost:${port}`);
  console.log('(API backed by the file-based Netlify Blobs test shim)');
});
