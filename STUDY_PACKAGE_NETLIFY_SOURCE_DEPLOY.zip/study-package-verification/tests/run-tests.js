'use strict';

/*
 * STUDY PACKAGE VERIFICATION — automated test suite.
 *
 * Runs the REAL serverless function handlers against a file-backed
 * @netlify/blobs test shim (tests/shims), simulating the persistent
 * Netlify Blobs store — including persistence across separate processes
 * (which simulates browser restarts, refreshes and redeployments).
 *
 * Run from the project root:  node tests/run-tests.js
 */

const Module = require('module');
const path = require('path');
const fs = require('fs');
const assert = require('assert');
const { spawnSync } = require('child_process');

// --- Redirect @netlify/blobs to the local test shim (before anything requires it)
const SHIM = path.join(__dirname, 'shims', '@netlify', 'blobs', 'index.js');
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function (request, ...rest) {
  if (request === '@netlify/blobs') return SHIM;
  return originalResolve.call(this, request, ...rest);
};

const DATA_FILE = path.join(__dirname, '.mock-blobs.json');
process.env.BLOBS_MOCK_FILE = DATA_FILE;
process.env.BLOBS_MOCK_DELAY_MS = process.env.BLOBS_MOCK_DELAY_MS || '1'; // stress the locks
process.env.SPV_DISABLE_THROTTLE = '1';

const loginFn = require('../netlify/functions/login.js');
const spinFn = require('../netlify/functions/spin.js');
const sessionFn = require('../netlify/functions/session.js');
const storeLib = require('../netlify/functions/_lib/store.js');

const CREDENTIALS = {
  Kani: 'Kani18', Maya: 'Maya17', Vuti: 'Vuti17', Oara: 'Oara17',
  Keems: 'Keems18', Wonga: 'Wonga18', Gere: 'Gere18', Mpumi: 'Mpumi18',
};
const ALL_NAMES = ['Kani', 'Maya', 'Vuti', 'Oara', 'Keems', 'Wonga', 'Gere', 'Mpumi'];
const FIXED = { Kani: 'Gere', Gere: 'Kani', Keems: 'Mpumi', Mpumi: 'Keems' };
const POOL = ['Maya', 'Vuti', 'Oara', 'Wonga'];

/* ---------------- tiny test runner ---------------- */

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

function resetStore() { try { fs.unlinkSync(DATA_FILE); } catch { /* fresh */ } }

async function call(fn, opts) {
  opts = opts || {};
  const event = {
    httpMethod: opts.method || 'POST',
    headers: opts.token ? { authorization: 'Bearer ' + opts.token } : {},
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    path: '/api/test',
    queryStringParameters: {},
  };
  const res = await fn.handler(event);
  let data = null;
  try { data = JSON.parse(res.body); } catch { /* empty body */ }
  return { status: res.statusCode, data, raw: res.body || '' };
}

const login = (username, password) => call(loginFn, { body: { username, password } });
const spin = (token) => call(spinFn, { token });
const getSession = (token) => call(sessionFn, { method: 'GET', token });

function namesIn(text) { return ALL_NAMES.filter((n) => text.includes(n)); }

/* ---------------- tests ---------------- */

test('all eight authorized credentials can log in and passwords remain reusable', async () => {
  resetStore();
  const tokens = new Set();
  for (const [username, password] of Object.entries(CREDENTIALS)) {
    const res = await login(username, password);
    assert.strictEqual(res.status, 200, `${username} login failed: ${res.raw}`);
    assert.strictEqual(res.data.ok, true);
    assert.strictEqual(res.data.username, username);
    assert.ok(!('recovered' in res.data), 'login response should not expose one-time-use state');
    assert.strictEqual(res.data.revealed, false);
    assert.ok(!('partner' in res.data), 'partner must not be exposed before the reveal');
    assert.ok(res.data.token && !tokens.has(res.data.token), 'tokens must be unique');
    tokens.add(res.data.token);
  }
});

test('a wrong password is rejected and does NOT consume the account', async () => {
  resetStore();
  const bad = await login('Kani', 'wrong-password');
  assert.strictEqual(bad.status, 401);
  assert.ok(!bad.data.token);
  const good = await login('Kani', 'Kani18');
  assert.strictEqual(good.status, 200);
  assert.ok(!('recovered' in good.data), 'login response should not expose one-time-use state');
  const again = await login('Kani', 'Kani18');
  assert.strictEqual(again.status, 200);
  assert.strictEqual(again.status, 200, 'password must remain reusable');
  assert.notStrictEqual(again.data.token, good.data.token, 'each login should create a fresh session token');
});

test('unknown usernames, wrong case, and malformed requests are rejected', async () => {
  resetStore();
  assert.strictEqual((await login('kani', 'Kani18')).status, 401, 'usernames are case-sensitive');
  assert.strictEqual((await login('Kani ', 'Kani18')).status, 200, 'surrounding whitespace is trimmed');
  assert.strictEqual((await login('Zane', 'whatever')).status, 401);
  assert.strictEqual((await login('', '')).status, 400);
  assert.strictEqual((await call(loginFn, { method: 'GET' })).status, 405);
});

test('partner assignments are generated once, before the first reveal, and never change', async () => {
  resetStore();
  await login('Maya', 'Maya17'); // first login triggers initialization
  const snapshot = {};
  for (const name of ALL_NAMES) snapshot[name] = await storeLib.getAssignment(name);
  for (const name of ALL_NAMES) assert.ok(snapshot[name], `missing assignment for ${name}`);
  for (const [a, b] of Object.entries(FIXED)) {
    assert.strictEqual(snapshot[a], b, `fixed pair ${a} -> ${b}`);
  }
  for (const member of POOL) {
    assert.ok(POOL.includes(snapshot[member]), `${member} assigned outside the pool`);
    assert.notStrictEqual(snapshot[member], member, `${member} assigned to themselves`);
  }
  await storeLib.ensureInitialized();
  await storeLib.ensureInitialized();
  for (const name of ALL_NAMES) {
    assert.strictEqual(await storeLib.getAssignment(name), snapshot[name], 'assignments must be permanent');
  }
});

test('simultaneous logins all succeed with reusable passwords', async () => {
  resetStore();
  const attempts = await Promise.all(Array.from({ length: 20 }, () => login('Maya', 'Maya17')));
  for (const res of attempts) assert.strictEqual(res.status, 200);
  assert.strictEqual(new Set(attempts.map((r) => r.data.token)).size, 20, 'each login should receive a unique token');
  const record = await storeLib.getAccountRecord('Maya');
  assert.strictEqual(record.logins, 20);
  assert.ok(!('consumed' in record), 'account must not be marked consumed');
});

test('simultaneous failed logins never consume the account', async () => {
  resetStore();
  const bad = await Promise.all(Array.from({ length: 10 }, () => login('Vuti', 'nope')));
  for (const res of bad) assert.strictEqual(res.status, 401);
  const good = await login('Vuti', 'Vuti17');
  assert.strictEqual(good.status, 200);
  assert.ok(!('recovered' in good.data), 'login response should not expose one-time-use state');
});

test('fixed-pair participants reveal their fixed partner exactly once', async () => {
  resetStore();
  for (const [username, expected] of Object.entries(FIXED)) {
    const loginRes = await login(username, CREDENTIALS[username]);
    assert.strictEqual(loginRes.status, 200);
    const token = loginRes.data.token;
    const first = await spin(token);
    assert.strictEqual(first.status, 200);
    assert.strictEqual(first.data.partner, expected, `${username} must reveal ${expected}`);
    assert.strictEqual(first.data.alreadyRevealed, false);
    const second = await spin(token);
    assert.strictEqual(second.status, 200);
    assert.strictEqual(second.data.alreadyRevealed, true, 'second spin must be locked');
    assert.strictEqual(second.data.partner, expected, 'recovery must return the same partner');
    const sess = await getSession(token);
    assert.strictEqual(sess.data.revealed, true);
    assert.strictEqual(sess.data.partner, expected);
  }
});

test('pool participants receive valid independent random partners', async () => {
  resetStore();
  const seen = {};
  for (const username of POOL) {
    const loginRes = await login(username, CREDENTIALS[username]);
    const token = loginRes.data.token;
    const res = await spin(token);
    assert.strictEqual(res.status, 200);
    assert.ok(POOL.includes(res.data.partner), `${username} got a partner outside the pool`);
    assert.notStrictEqual(res.data.partner, username, `${username} cannot partner with themselves`);
    seen[username] = res.data.partner;
  }
  assert.strictEqual(Object.keys(seen).length, 4);
});

test('simultaneous spins produce exactly one reveal and one consistent result', async () => {
  resetStore();
  const loginRes = await login('Wonga', 'Wonga18');
  const token = loginRes.data.token;
  const spins = await Promise.all(Array.from({ length: 20 }, () => spin(token)));
  for (const res of spins) assert.strictEqual(res.status, 200);
  const firstSpins = spins.filter((r) => r.data.alreadyRevealed === false);
  assert.strictEqual(firstSpins.length, 1, 'exactly one spin may consume the reveal');
  const partners = new Set(spins.map((r) => r.data.partner));
  assert.strictEqual(partners.size, 1, 'every response must return the same saved partner');
  const reveal = await storeLib.getReveal('Wonga');
  assert.ok(reveal && reveal.partner);
  assert.ok(reveal.consumedAt);
});

test('unauthorized requests are rejected without leaking anything', async () => {
  resetStore();
  const noToken = await spin(undefined);
  assert.strictEqual(noToken.status, 401);
  const badToken = await spin('deadbeef');
  assert.strictEqual(badToken.status, 401);
  const noTokenSession = await getSession(undefined);
  assert.strictEqual(noTokenSession.status, 401);
  const badTokenSession = await getSession('deadbeef');
  assert.strictEqual(badTokenSession.status, 401);
  for (const res of [noToken, badToken, noTokenSession, badTokenSession]) {
    assert.ok(!('partner' in (res.data || {})), 'no partner data in error responses');
    assert.strictEqual(namesIn(res.raw).length, 0, 'no participant names in error responses');
  }
});

test('API responses never expose other participants or the assignment table', async () => {
  resetStore();
  const loginRes = await login('Maya', 'Maya17');
  const token = loginRes.data.token;

  const spinRes = await spin(token);
  const allowedSpinKeys = ['ok', 'username', 'alreadyRevealed', 'partner'];
  for (const key of Object.keys(spinRes.data)) {
    assert.ok(allowedSpinKeys.includes(key), `unexpected key "${key}" in spin response`);
  }
  assert.ok(namesIn(spinRes.raw).length <= 2, 'spin response may only mention the user and their own partner');

  const sessRes = await getSession(token);
  const allowedSessionKeys = ['ok', 'username', 'revealed', 'partner'];
  for (const key of Object.keys(sessRes.data)) {
    assert.ok(allowedSessionKeys.includes(key), `unexpected key "${key}" in session response`);
  }

  const loginRes2 = await login('Oara', 'Oara17');
  const allowedLoginKeys = ['ok', 'token', 'username', 'recovered', 'revealed', 'partner'];
  for (const key of Object.keys(loginRes2.data)) {
    assert.ok(allowedLoginKeys.includes(key), `unexpected key "${key}" in login response`);
  }
});

test('repeated password logins create sessions and preserve partner access', async () => {
  resetStore();
  const first = await login('Oara', 'Oara17');
  assert.ok(!('recovered' in first.data));
  const tokenA = first.data.token;
  const spinRes = await spin(tokenA);
  const partner = spinRes.data.partner;

  const second = await login('Oara', 'Oara17');
  assert.strictEqual(second.status, 200);
  assert.ok(!('recovered' in second.data), 'login should not expose one-time-use state');
  assert.strictEqual(second.data.revealed, true);
  assert.strictEqual(second.data.partner, partner);
  const tokenB = second.data.token;

  const sessB = await getSession(tokenB);
  assert.strictEqual(sessB.status, 200);
  assert.strictEqual(sessB.data.username, 'Oara');
  assert.strictEqual(sessB.data.partner, partner);

  const sessA = await getSession(tokenA);
  assert.strictEqual(sessA.status, 200, 'the original session also remains valid');

  const spinB = await spin(tokenB);
  assert.strictEqual(spinB.data.alreadyRevealed, true);
  assert.strictEqual(spinB.data.partner, partner);

  const record = await storeLib.getAccountRecord('Oara');
  assert.ok(!('consumed' in record), 'account must not be marked consumed');
  const third = await login('Oara', 'Oara17');
  assert.strictEqual(third.status, 200, 'password should work any number of times');
});

test('all state survives restarts and redeployments (separate process, same store)', async () => {
  resetStore();
  const child = spawnSync(process.execPath, [path.join(__dirname, 'child-probe.js')], {
    env: { ...process.env, BLOBS_MOCK_FILE: DATA_FILE },
    encoding: 'utf8',
  });
  assert.strictEqual(child.status, 0, `child probe failed: ${child.stderr}`);
  const childResult = JSON.parse(child.stdout.trim().split('\n').pop());
  assert.strictEqual(childResult.alreadyRevealed, false);

  const loginRes = await login('Maya', 'Maya17');
  assert.strictEqual(loginRes.status, 200, 'password remains reusable across processes');
  const spinRes = await spin(loginRes.data.token);
  assert.strictEqual(spinRes.data.alreadyRevealed, true, 'reveal persisted across processes');
  assert.strictEqual(spinRes.data.partner, childResult.partner, 'same saved partner returned');
  assert.strictEqual(await storeLib.getAssignment('Maya'), childResult.partner, 'assignment persisted across processes');
});

test('the wheel shows exactly the other seven names, in canonical order', async () => {
  delete require.cache[require.resolve('../site/js/logic.js')];
  require('../site/js/logic.js');
  const SPV = globalThis.SPV;
  assert.ok(SPV, 'SPV logic must load');
  assert.deepStrictEqual(SPV.PARTICIPANTS, ALL_NAMES);
  for (const name of ALL_NAMES) {
    const expected = ALL_NAMES.filter((n) => n !== name);
    assert.deepStrictEqual(SPV.wheelNamesFor(name), expected, `wheel names for ${name}`);
  }
  assert.deepStrictEqual(
    SPV.wheelNamesFor('Maya'),
    ['Kani', 'Vuti', 'Oara', 'Keems', 'Wonga', 'Gere', 'Mpumi'],
    'spec example for Maya'
  );
});

test('frontend files contain no plaintext passwords or secrets', async () => {
  const siteDir = path.join(__dirname, '..', 'site');
  const files = [];
  (function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else files.push(full);
    }
  })(siteDir);
  assert.ok(files.length >= 4, 'expected site files');
  for (const file of files) {
    const content = fs.readFileSync(file, 'utf8');
    for (const [username, password] of Object.entries(CREDENTIALS)) {
      assert.ok(!content.includes(password), `${path.basename(file)} leaks the password for ${username}`);
    }
    assert.ok(!content.includes('scrypt$'), `${path.basename(file)} leaks password hashes`);
    assert.ok(!content.includes('fixedPairs'), `${path.basename(file)} leaks assignment logic`);
  }
});

test('Netlify project configuration is complete', async () => {
  const root = path.join(__dirname, '..');
  const toml = fs.readFileSync(path.join(root, 'netlify.toml'), 'utf8');
  assert.ok(/publish\s*=\s*"site"/.test(toml), 'netlify.toml must publish site/');
  assert.ok(/functions\s*=\s*"netlify\/functions"/.test(toml), 'netlify.toml must declare functions dir');
  for (const f of ['login.js', 'spin.js', 'session.js']) {
    assert.ok(fs.existsSync(path.join(root, 'netlify', 'functions', f)), `missing function ${f}`);
  }
  assert.ok(fs.existsSync(path.join(root, 'netlify', 'functions', '_lib', 'credentials.js')));
  assert.ok(fs.existsSync(path.join(root, 'site', 'index.html')));
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  assert.ok(pkg.dependencies['@netlify/blobs'], 'functions need @netlify/blobs');
});

/* ---------------- run ---------------- */

(async () => {
  console.log('STUDY PACKAGE VERIFICATION — test suite\n');
  let passed = 0;
  const failures = [];
  for (const t of tests) {
    try {
      await t.fn();
      passed += 1;
      console.log('  PASS  ' + t.name);
    } catch (err) {
      failures.push(t.name);
      console.log('  FAIL  ' + t.name);
      console.log('        ' + String(err && err.message).split('\n').join('\n        '));
    }
  }
  console.log(`\n${passed}/${tests.length} tests passed.`);
  if (failures.length) {
    console.log('Failed: ' + failures.join('; '));
    process.exit(1);
  }
})();
