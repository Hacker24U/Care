'use strict';

/*
 * Child-process probe: simulates a SEPARATE deployment/process using the same
 * persistent store (like a redeploy or a different browser/device). It logs in
 * as Maya and performs her one-time spin, then prints the result as JSON.
 * The parent test (run-tests.js) verifies the state afterwards.
 */

const Module = require('module');
const path = require('path');

const SHIM = path.join(__dirname, 'shims', '@netlify', 'blobs', 'index.js');
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function (request, ...rest) {
  if (request === '@netlify/blobs') return SHIM;
  return originalResolve.call(this, request, ...rest);
};

process.env.SPV_DISABLE_THROTTLE = '1';

const loginFn = require('../netlify/functions/login.js');
const spinFn = require('../netlify/functions/spin.js');

(async () => {
  const loginRes = await loginFn.handler({
    httpMethod: 'POST',
    headers: {},
    body: JSON.stringify({ username: 'Maya', password: 'Maya17' }),
  });
  const token = JSON.parse(loginRes.body).token;

  const spinRes = await spinFn.handler({
    httpMethod: 'POST',
    headers: { authorization: 'Bearer ' + token },
    body: '',
  });
  const data = JSON.parse(spinRes.body);

  process.stdout.write(JSON.stringify({
    partner: data.partner,
    alreadyRevealed: data.alreadyRevealed,
  }));
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
