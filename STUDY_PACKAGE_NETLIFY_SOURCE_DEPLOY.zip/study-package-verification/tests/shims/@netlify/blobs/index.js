'use strict';

/*
 * LOCAL TEST SHIM for @netlify/blobs (used only by tests/ and the local dev
 * server — the real package is installed automatically by Netlify when the
 * site is deployed).
 *
 * File-backed key-value store that mimics the real Netlify Blobs semantics:
 *  - strong consistency (every read observes the latest completed write)
 *  - persistence across processes (the file is the source of truth), which
 *    simulates state surviving browser restarts, refreshes and redeploys.
 *
 * Configure with environment variables:
 *   BLOBS_MOCK_FILE        path of the backing JSON file
 *   BLOBS_MOCK_DELAY_MS    artificial per-operation latency (race stress)
 */

const fs = require('fs');
const path = require('path');

const DATA_FILE = process.env.BLOBS_MOCK_FILE || path.join(__dirname, '.mock-blobs.json');
const DELAY_MS = Number(process.env.BLOBS_MOCK_DELAY_MS || 0);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function readData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function writeData(data) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(data));
}

function makeStore(namespace) {
  const prefix = `ns:${namespace}:`;

  // Every operation: optional delay, then a synchronous read-modify-write of
  // the backing file (atomic within the Node event loop).
  async function run(mutator) {
    if (DELAY_MS > 0) {
      await sleep(DELAY_MS + Math.floor(Math.random() * DELAY_MS));
    }
    const data = readData();
    const result = mutator(data);
    writeData(data);
    return result;
  }

  const store = {
    async get(key) {
      return run((data) => {
        const k = prefix + key;
        return Object.prototype.hasOwnProperty.call(data, k) ? data[k] : null;
      });
    },
    async set(key, value) {
      return run((data) => {
        data[prefix + key] = String(value);
        return true;
      });
    },
    async getJSON(key) {
      const value = await store.get(key);
      return value == null ? null : JSON.parse(value);
    },
    async setJSON(key, value) {
      return store.set(key, JSON.stringify(value));
    },
    async delete(key) {
      return run((data) => {
        const k = prefix + key;
        const had = Object.prototype.hasOwnProperty.call(data, k);
        delete data[k];
        return had;
      });
    },
    async list() {
      return run((data) => ({
        blobs: Object.keys(data)
          .filter((k) => k.startsWith(prefix))
          .map((k) => ({ key: k.slice(prefix.length) })),
      }));
    },
  };

  return store;
}

const stores = new Map();

function getStore(nameOrOptions) {
  const name =
    typeof nameOrOptions === 'string'
      ? nameOrOptions
      : (nameOrOptions && nameOrOptions.name) || 'default';
  if (!stores.has(name)) stores.set(name, makeStore(name));
  return stores.get(name);
}

module.exports = { getStore };
